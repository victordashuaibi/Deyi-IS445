# IS-445_Final_Project : Urbana Police Arrests


## About the Dataset:
The dataset contains information about arrests made in the City of Urbana by the Urbana Police Department dating back to 1988.
Dataset Information:
Number of Columns: 19
Number of Rows: 1000
Updates quarterly

https://data.urbanaillinois.us/Police/Urbana-Police-Arrests-Since-1988/afbd-8beq

This project we will be visualizing and helping our Viewers understand all the necessary 
information based on the crimes taking place in Urbana and also information about Arrestee, 
the year they were arrested, the crime they did and what punishment or resolution was passed against them.
